class Number < ActiveRecord::Base
  validates :power, :presence => true
  validates :power, :uniqueness => true
end
